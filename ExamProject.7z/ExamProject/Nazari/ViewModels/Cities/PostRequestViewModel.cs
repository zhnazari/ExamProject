﻿//namespace MyApplication.ViewModels.Users
namespace ViewModels.Users
{
	public class PostRequestViewModel : object
	{
		public PostRequestViewModel() : base()
		{
		}

		public string Id { get; set; }

		public string CityName { get; set; }

	}
}
