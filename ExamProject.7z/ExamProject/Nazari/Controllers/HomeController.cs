﻿namespace MyApplication.Controllers
{
    public class HomeController : Microsoft.AspNetCore.Mvc.Controller
    {
        public HomeController() : base()
        {
        }

        public string Index()
        {
            return "I'm Sattar";
        }

        /// <summary>
        /// services.AddControllersWithViews();
        /// </summary>
        public Microsoft.AspNetCore.Mvc.IActionResult CityView()
        {
            return View();
        }

        
        
    }
}