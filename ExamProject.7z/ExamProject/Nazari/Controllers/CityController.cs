﻿using System.Linq;

namespace MyApplication.Controllers
{
	[Microsoft.AspNetCore.Mvc.ApiController]
	[Microsoft.AspNetCore.Mvc.Route
		(template: Infrastructure.RouterConstants.Controller)]
	public class UsersController : Infrastructure.ApiControllerBase
	{
		#region Mock Users
		private static System.Collections.Generic.IList<Models.City> _cities;

		public static System.Collections.Generic.IList<Models.City> Cities
		{
			get
			{
				if (_cities == null)
				{
					_cities =
						new System.Collections.Generic.List<Models.City>();

					for (int index = 1; index <= 10; index++)
					{
						Models.City user =
							new Models.City()
							{
								Id = index,
								CityName = $"CityName { index }",
								
							};

						_cities.Add(user);
					}
				}

				return _cities;
			}
		}
		#endregion /Mock Users

		public UsersController() : base()
		{
		}

		#region Get All Method
		/// <summary>
		/// Get All
		/// </summary>
		/// <returns>Users</returns>
		[Microsoft.AspNetCore.Mvc.HttpGet]

		[Microsoft.AspNetCore.Mvc.ProducesResponseType
			(type: typeof(Models.City),
			statusCode: Microsoft.AspNetCore.Http.StatusCodes.Status200OK)]
		public
			async
			System.Threading.Tasks.Task
			<Microsoft.AspNetCore.Mvc.ActionResult<System.Collections.Generic.IList<Models.City>>>
			Get()
		{
			System.Collections.Generic.IList<Models.City> result = null;

			await System.Threading.Tasks.Task.Run(() =>
			{
				result =
					Cities
					.OrderBy(current => current.Id)
					.ToList()
					;
			});

			return Ok(value: result);
		}
		#endregion /Get All Method

		#region Get By Id Method
		/// <summary>
		/// Get By Id
		/// </summary>
		/// <returns>User</returns>
		[Microsoft.AspNetCore.Mvc.HttpGet(template: "{id}")]

		[Microsoft.AspNetCore.Mvc.ProducesResponseType
			(type: typeof(Models.City),
			statusCode: Microsoft.AspNetCore.Http.StatusCodes.Status200OK)]

		[Microsoft.AspNetCore.Mvc.ProducesResponseType
			(type: typeof(string),
			statusCode: Microsoft.AspNetCore.Http.StatusCodes.Status404NotFound)]
		public
			async
			System.Threading.Tasks.Task
			<Microsoft.AspNetCore.Mvc.ActionResult<Models.City>>
			Get(int id)
		{
			Models.City city = null;

			await System.Threading.Tasks.Task.Run(() =>
			{
				city =
					Cities
					.Where(current => current.Id == id)
					.FirstOrDefault();
			});

			if (city == null)
			{
				return NotFound(value: "User not found!");
			}
			else
			{
				return Ok(value: city);
			}
		}
		#endregion /Get By Id Method

		#region Create a new user method
		/// <summary>
		/// Get By Id
		/// </summary>
		/// <returns>User</returns>
		[Microsoft.AspNetCore.Mvc.HttpPost]

		[Microsoft.AspNetCore.Mvc.ProducesResponseType
			(type: typeof(Models.City),
			statusCode: Microsoft.AspNetCore.Http.StatusCodes.Status200OK)]

		[Microsoft.AspNetCore.Mvc.ProducesResponseType
			(type: typeof(string),
			statusCode: Microsoft.AspNetCore.Http.StatusCodes.Status404NotFound)]
		public
			async
			System.Threading.Tasks.Task
			<Microsoft.AspNetCore.Mvc.ActionResult<Models.City>>
			
			Post([Microsoft.AspNetCore.Mvc.FromBody]
				ViewModels.Users.PostRequestViewModel viewModel)
		{
			Models.City newUser = null;

			await System.Threading.Tasks.Task.Run(() =>
			{
				int newId =
					Cities.Max(current => current.Id) + 1;

				newUser =
					new Models.City()
					{
						Id = newId,
						CityName = viewModel.CityName,
						
					};

				Cities.Add(newUser);
			});

			if (newUser == null)
			{
				return NotFound(value: "User not found!");
			}
			else
			{
				return Ok(value: newUser);
			}
		}
		#endregion /Create a new user method
	}
}
