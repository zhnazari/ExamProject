﻿// Models, ViewModels, Infrastructure

namespace Infrastructure
//namespace MyApplication.Infrastructure
{
	public class SomeClass
	{
	}
}
