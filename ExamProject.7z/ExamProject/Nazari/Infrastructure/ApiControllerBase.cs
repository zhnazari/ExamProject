﻿//namespace MyApplication.Infrastructure
namespace Infrastructure
{
	public class ApiControllerBase : Microsoft.AspNetCore.Mvc.ControllerBase
	{
		public ApiControllerBase() : base()
		{
		}
	}
}
