﻿//namespace MyApplication.Models
namespace Models
{
    public class City : object
        //public class User : System.Object
    {
        public City() : base()
        {
        }

        public int Id { get; set; }

        public string CityName { get; set; }


    }
}